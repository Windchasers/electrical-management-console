import Head from 'next/head'
import Image from 'next/image'

import styles from './index.module.css'
import { useEffect } from 'react'



export default function Users() {
  useEffect(()=>{

  })
  
  return (
    <div className={styles.contents}>
      contract-signed
    </div>
  )
}
